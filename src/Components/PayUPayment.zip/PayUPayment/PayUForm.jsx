

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useLocation, useNavigate } from 'react-router-dom';

const PayUForm = () => {
  const containerStyle = {
    maxWidth: '400px',
    margin: '50px auto',
    padding: '30px',
    borderRadius: '12px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
    backgroundColor: '#ffffff',
    fontFamily: 'Segoe UI, sans-serif',
  };

  const titleStyle = {
    textAlign: 'center',
    marginBottom: '25px',
    color: '#00ADF2',
    fontSize: '24px',
    fontWeight: 'bold',
  };

  const labelStyle = {
    display: 'block',
    marginBottom: '6px',
    fontWeight: '600',
  };

  const inputStyle = {
    width: '100%',
    padding: '10px',
    marginBottom: '18px',
    border: '1px solid #ccc',
    borderRadius: '8px',
    fontSize: '14px',
  };

  const buttonGroupStyle = {
    display: 'flex',
    justifyContent: 'space-between',
  };

  const buttonStyle = {
    flex: 1,
    padding: '10px 15px',
    margin: '0 5px',
    border: 'none',
    borderRadius: '8px',
    fontWeight: '600',
    cursor: 'pointer',
    color: '#fff',
    transition: 'background 0.3s ease',
  };

  const payNowStyle = {
    ...buttonStyle,
    backgroundColor: '#00ADF2',
  };

  const payLaterStyle = {
    ...buttonStyle,
    backgroundColor: '#fff',
    color: '#00ADF2',
    boxShadow: '0 2px 8px rgba(0, 123, 255, 0.3)',
  };

  const location = useLocation();
  const navigate = useNavigate();

  const { planName = '', amount = '', phoneNumber = '', planId = '' } = location.state || {};

  const [form, setForm] = useState({
    txnid: 'txn_' + Date.now(),
    amount: '',
    productinfo: 'Subscription Plan',
    firstname: 'Owner',
    email: `owner${Date.now()}@gmail.com`,
    phone: '',
    planName: '',
    planId: '',
  });

  const [popup, setPopup] = useState({
    visible: false,
    message: '',
    type: '',
    planName: '',
    onConfirm: null,
  });

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setForm((prev) => ({
      ...prev,
      planName,
      amount,
      phone: phoneNumber,
      planId,
    }));
  }, [planName, amount, phoneNumber, planId]);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const initiatePayUPayment = async () => {
    const postData = { ...form, payustatususer: 'pay now' };
    const response = await axios.post(`${process.env.REACT_APP_API_URL}/payu/payment`, postData);
    const payuData = response.data;

    const formElement = document.createElement('form');
    formElement.method = 'POST';
    formElement.action = 'https://secure.payu.in/_payment';

    Object.entries(payuData).forEach(([key, value]) => {
      const input = document.createElement('input');
      input.type = 'hidden';
      input.name = key;
      input.value = value;
      formElement.appendChild(input);
    });

    document.body.appendChild(formElement);
    formElement.submit();
  };

  const handlePayNow = async () => {
    if (!form.amount || !form.firstname || !form.email || !form.phone || !form.planName) {
      setPopup({
        visible: true,
        message: 'Please fill all required fields.',
        type: 'error',
      });
      return;
    }

    try {
      setLoading(true);
      await axios.post(`${process.env.REACT_APP_API_URL}/select-plan`, {
        phoneNumber: form.phone,
        planId: form.planId,
      });

      await initiatePayUPayment();
    } catch (error) {
      const errMsg = error?.response?.data?.message || 'Something went wrong.';
      if (errMsg.includes('already selected')) {
        setPopup({
          visible: true,
          message: `You have already selected ${planName} plan. Please complete payment.`,
          planName,
          type: 'info',
        });
      } else {
        setPopup({
          visible: true,
          message: errMsg,
          type: 'error',
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handlePayLater = async () => {
    if (!form.amount || !form.firstname || !form.email || !form.phone || !form.planName) {
      setPopup({
        visible: true,
        message: 'Please fill all required fields.',
        type: 'error',
      });
      return;
    }

    try {
      const postData = { ...form, payustatususer: 'pay later' };
      await axios.post(`${process.env.REACT_APP_API_URL}/payu/payment-later`, postData);

      setPopup({
        visible: true,
        message: 'Your request to pay later is saved successfully.',
        type: 'success',
      });

      setForm((prev) => ({
        ...prev,
        txnid: 'txn_' + Date.now(),
        email: `owner${Date.now()}@gmail.com`,
      }));
    } catch (error) {
      setPopup({
        visible: true,
        message: 'Failed to save pay later. Please try again.',
        type: 'error',
      });
    }
  };

  const handleContinue = async () => {
    setPopup({ visible: false, message: '', type: '', planName: '' });
    await initiatePayUPayment();
  };

  // const handleRemove = async () => {
  //   try {
  //     await axios.put(`${process.env.REACT_APP_API_URL}/plans/remove-phone/${form.phone}`);
  //     setPopup({
  //       visible: true,
  //       message: 'Phone number removed from selected plan.',
  //       type: 'success',
  //       planName: '',
  //     });
  //   } catch (err) {
  //     setPopup({
  //       visible: true,
  //       message: 'Failed to remove phone number. Please try again.',
  //       type: 'error',
  //     });
  //   }
  // };

  const handleRemove = async () => {
  try {
    await axios.put(`${process.env.REACT_APP_API_URL}/plans/remove-phone/${form.phone}`);
    setPopup({
      visible: true,
      message: 'Phone number removed from selected plan.',
      type: 'success',
      planName: '',
    });

    // Navigate after a short delay to allow popup display
    setTimeout(() => {
      navigate('/add-plan');
    }, 2500); 
  } catch (err) {
    setPopup({
      visible: true,
      message: 'Failed to remove phone number. Please try again.',
      type: 'error',
    });
  }
};


  return (
    <div style={containerStyle}>
      <h2 style={titleStyle}>PayU Payment</h2>
      <form>
        <label style={labelStyle}>Plan</label>
        <input type="text" value={form.planName} readOnly style={inputStyle} />

        <label style={labelStyle}>Amount</label>
        <input type="number" value={form.amount} readOnly style={inputStyle} />

        <label style={labelStyle}>Phone Number</label>
        <input type="tel" value={form.phone} readOnly style={inputStyle} />

        <label style={labelStyle}>Full Name</label>
        <input type="text" name="firstname" value={form.firstname} onChange={handleChange} style={inputStyle} />

        <label style={labelStyle}>Email</label>
        <input type="email" name="email" value={form.email} onChange={handleChange} style={inputStyle} />

        <div style={buttonGroupStyle}>
          <button type="button" style={payLaterStyle} onClick={handlePayLater} disabled={loading}>
            Pay Later
          </button>
          <button type="submit" style={payNowStyle} onClick={handlePayNow} disabled={loading}>
            {loading ? 'Processing...' : 'Pay Now'}
          </button>
        </div>
      </form>

      {popup.visible && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0,0,0,0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 9999,
          }}
        >
          <div
            style={{
              backgroundColor: '#fff',
              padding: 20,
              borderRadius: 10,
              textAlign: 'center',
              maxWidth: 320,
              color: popup.type === 'error' ? 'red' : 'black',
            }}
          >
            <p>{popup.message}</p>

            {popup.planName ? (
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10 }}>
                <button onClick={handleContinue} style={{ background: 'blue', color: 'white', padding: '6px 10px', borderRadius: 6 }}>
                  Continue to Pay
                </button>
                <button
                  onClick={handleRemove}
                  style={{
                    background: 'white',
                    color: 'blue',
                    boxShadow: '0 4px 8px rgba(0, 123, 255, 0.3)',
                    padding: '6px 10px',
                    borderRadius: 6,
                  }}
                >
                  Remove
                </button>
              </div>
            ) : (
              <button
                onClick={() => setPopup({ visible: false, message: '', type: '', planName: '' })}
                style={{
                  marginTop: 10,
                  padding: '6px 12px',
                  background: '#00ADF2',
                  color: 'white',
                  borderRadius: '6px',
                  border: 'none',
                }}
              >
                OK
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default PayUForm;




































// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { useLocation, useNavigate } from 'react-router-dom';

// const PayUForm = () => {
//     const containerStyle = {
//     maxWidth: '400px',
//     margin: '50px auto',
//     padding: '30px',
//     borderRadius: '12px',
//     boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
//     backgroundColor: '#ffffff',
//     fontFamily: 'Segoe UI, sans-serif',
//   };

//   const titleStyle = {
//     textAlign: 'center',
//     marginBottom: '25px',
//     color: '#00ADF2',
//     fontSize: '24px',
//     fontWeight: 'bold',
//   };

//   const labelStyle = {
//     display: 'block',
//     marginBottom: '6px',
//     fontWeight: '600',
//   };

//   const inputStyle = {
//     width: '100%',
//     padding: '10px',
//     marginBottom: '18px',
//     border: '1px solid #ccc',
//     borderRadius: '8px',
//     fontSize: '14px',
//   };

//   const buttonGroupStyle = {
//     display: 'flex',
//     justifyContent: 'space-between',
//   };

//   const buttonStyle = {
//     flex: 1,
//     padding: '10px 15px',
//     margin: '0 5px',
//     border: 'none',
//     borderRadius: '8px',
//     fontWeight: '600',
//     cursor: 'pointer',
//     color: '#fff',
//     transition: 'background 0.3s ease',
//   };

//   const payNowStyle = {
//     ...buttonStyle,
//     backgroundColor: '#00ADF2',
//   };

//   const payLaterStyle = {
//     ...buttonStyle,
//     backgroundColor: '#fff',
//     color:"#00ADF2",
//         boxShadow: '0 2px 8px rgba(0, 123, 255, 0.3)'

//   };

//   const location = useLocation();
//   const navigate = useNavigate();

//   const { planName = '', amount = '', phoneNumber = '', planId = '' } = location.state || {};

//   const [form, setForm] = useState({
//     txnid: 'txn_' + Date.now(),
//     amount: '',
//     productinfo: 'Subscription Plan',
//     firstname: 'Owner',
//     email: 'owner@gmail.com',
//     phone: '',
//     planName: '',
//     planId: '',
//   });

//   const [popup, setPopup] = useState({
//     visible: false,
//     message: '',
//     planName: '',
//   });

//   const [loading, setLoading] = useState(false);

//   useEffect(() => {
//     setForm((prev) => ({
//       ...prev,
//       planName,
//       amount,
//       phone: phoneNumber,
//       planId,
//     }));
//   }, [planName, amount, phoneNumber, planId]);

//   const handleChange = (e) => {
//     setForm({
//       ...form,
//       [e.target.name]: e.target.value,
//     });
//   };

//   const initiatePayUPayment = async () => {
//     const postData = { ...form, payustatususer: 'pay now' };
//     const response = await axios.post(`${process.env.REACT_APP_API_URL}/payu/payment`, postData);
//     const payuData = response.data;

//     const formElement = document.createElement('form');
//     formElement.method = 'POST';
//     formElement.action = 'https://secure.payu.in/_payment';

//     Object.entries(payuData).forEach(([key, value]) => {
//       const input = document.createElement('input');
//       input.type = 'hidden';
//       input.name = key;
//       input.value = value;
//       formElement.appendChild(input);
//     });

//     document.body.appendChild(formElement);
//     formElement.submit();
//   };

//   const handlePayNow = async () => {
//     if (!form.amount || !form.firstname || !form.email || !form.phone || !form.planName) {
//       alert('Please fill all required fields.');
//       return;
//     }

//     try {
//       setLoading(true);
//       const res = await axios.post(`${process.env.REACT_APP_API_URL}/select-plan`, {
//         phoneNumber: form.phone,
//         planId: form.planId,
//       });

//       // If successful, initiate PayU
//       await initiatePayUPayment();
//     } catch (error) {
//       const errMsg = error?.response?.data?.message || 'Something went wrong.';
//       if (errMsg.includes('already selected')) {
//         // Trigger popup
//         setPopup({
//           visible: true,
//           message: `You have already selected ${planName} plan. Please complete payment.`,
//           planName,
//         });
//       } else {
//         alert(errMsg);
//       }
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handlePayLater = async () => {
//     if (!form.amount || !form.firstname || !form.email || !form.phone || !form.planName) {
//       alert('Please fill all required fields.');
//       return;
//     }

//     try {
//       const postData = { ...form, payustatususer: 'pay later' };
//       await axios.post(`${process.env.REACT_APP_API_URL}/payu/payment-later`, postData);
//       alert('Your request to pay later is saved successfully.');
//       setForm((prev) => ({
//         ...prev,
//         txnid: 'txn_' + Date.now(),
//       }));
//     } catch (error) {
//       alert('Failed to save pay later. Please try again.');
//     }
//   };

//   const handleContinue = async () => {
//     setPopup({ visible: false, message: '', planName: '' });
//     await initiatePayUPayment(); // Continue payment
//   };

//   const handleRemove = async () => {
//     try {
//       await axios.put(`${process.env.REACT_APP_API_URL}/plans/remove-phone/${form.phone}`);
//       alert('Phone number removed from selected plan.');
//       setPopup({ visible: false, message: '', planName: '' });
//     } catch (err) {
//       alert('Failed to remove phone number. Please try again.');
//     }
//   };

//   return (
   
//   <div style={containerStyle}>
//       <h2 style={titleStyle}>PayU Payment</h2>
//       <form>
//         <label style={labelStyle}>Plan</label>
//         <input type="text" placeholder="e.g., Silver" value={form.planName} readOnly style={inputStyle} />

//         <label style={labelStyle}>Amount</label>
//         <input type="number" min="1" placeholder="1" value={form.amount} readOnly style={inputStyle} />

//         <label style={labelStyle}>Phone Number</label>
//         <input type="tel" placeholder="Enter your phone number" value={form.phone} readOnly style={inputStyle} />

//         <label style={labelStyle}>Full Name</label>
//         <input type="text" name="firstname" placeholder="Full Name"  value={form.firstname} onChange={handleChange} style={inputStyle} />

//         <label style={labelStyle}>Email</label>
//         <input type="email"  name="email" placeholder="Email" value={form.email} onChange={handleChange} style={inputStyle} />

//         <div style={buttonGroupStyle}>
//                     <button type="button" style={payLaterStyle} onClick={handlePayLater} disabled={loading}>Pay Later</button>
//           <button type="submit" style={payNowStyle} onClick={handlePayNow} disabled={loading}> {loading ? 'Processing...' : 'Pay Now'}</button>
//         </div>
//       </form>
//       {/* POPUP MODAL */}
//       {popup.visible && (
//         <div
//         style={{
//           position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
//           backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex',
//           justifyContent: 'center', alignItems: 'center', zIndex: 9999
//         }}>
//           <div style={{
//             backgroundColor: '#fff', padding: 20, borderRadius: 10,
//             textAlign: 'center', maxWidth: 300, color:"grey"
//           }}>
//             <p>{popup.message}</p>
//             <div className="d-flex justify-content-between">
//                 <button onClick={handleContinue} style={{ background:"blue", color:"white" }}>
//               Continue to Pay
//             </button>
//             <button onClick={handleRemove} style={{ background:"white", color:"blue",boxShadow: '0 4px 8px rgba(0, 123, 255, 0.3)',
//  }}>Remove</button>
//             </div>
          
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default PayUForm;












// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { useLocation, useNavigate } from 'react-router-dom';

// const PayUForm = () => {
//   const containerStyle = {
//     maxWidth: '400px',
//     margin: '50px auto',
//     padding: '30px',
//     borderRadius: '12px',
//     boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
//     backgroundColor: '#ffffff',
//     fontFamily: 'Segoe UI, sans-serif',
//   };

//   const titleStyle = {
//     textAlign: 'center',
//     marginBottom: '25px',
//     color: '#00ADF2',
//     fontSize: '24px',
//     fontWeight: 'bold',
//   };

//   const labelStyle = {
//     display: 'block',
//     marginBottom: '6px',
//     fontWeight: '600',
//   };

//   const inputStyle = {
//     width: '100%',
//     padding: '10px',
//     marginBottom: '18px',
//     border: '1px solid #ccc',
//     borderRadius: '8px',
//     fontSize: '14px',
//   };

//   const buttonGroupStyle = {
//     display: 'flex',
//     justifyContent: 'space-between',
//   };

//   const buttonStyle = {
//     flex: 1,
//     padding: '10px 15px',
//     margin: '0 5px',
//     border: 'none',
//     borderRadius: '8px',
//     fontWeight: '600',
//     cursor: 'pointer',
//     color: '#fff',
//     transition: 'background 0.3s ease',
//   };

//   const payNowStyle = {
//     ...buttonStyle,
//     backgroundColor: '#00ADF2',
//   };

//   const payLaterStyle = {
//     ...buttonStyle,
//     backgroundColor: '#fff',
//     color: '#00ADF2',
//     boxShadow: '0 2px 8px rgba(0, 123, 255, 0.3)',
//   };

//   const location = useLocation();
//   const navigate = useNavigate();

//   const { planName = '', amount = '', phoneNumber = '', planId = '' } = location.state || {};

//   const [form, setForm] = useState({
//     txnid: 'txn_' + Date.now(),
//     amount: '',
//     productinfo: 'Subscription Plan',
//     firstname: 'Owner',
//     email: `owner${Date.now()}@gmail.com`, // Dynamic email based on timestamp
//     phone: '',
//     planName: '',
//     planId: '',
//   });

//   const [popup, setPopup] = useState({
//     visible: false,
//     message: '',
//     planName: '',
//   });

//   const [loading, setLoading] = useState(false);

//   useEffect(() => {
//     setForm((prev) => ({
//       ...prev,
//       planName,
//       amount,
//       phone: phoneNumber,
//       planId,
//     }));
//   }, [planName, amount, phoneNumber, planId]);

//   const handleChange = (e) => {
//     setForm({
//       ...form,
//       [e.target.name]: e.target.value,
//     });
//   };

//   const initiatePayUPayment = async () => {
//     const postData = { ...form, payustatususer: 'pay now' };
//     const response = await axios.post(`${process.env.REACT_APP_API_URL}/payu/payment`, postData);
//     const payuData = response.data;

//     const formElement = document.createElement('form');
//     formElement.method = 'POST';
//     formElement.action = 'https://secure.payu.in/_payment';

//     Object.entries(payuData).forEach(([key, value]) => {
//       const input = document.createElement('input');
//       input.type = 'hidden';
//       input.name = key;
//       input.value = value;
//       formElement.appendChild(input);
//     });

//     document.body.appendChild(formElement);
//     formElement.submit();
//   };

//   const handlePayNow = async () => {
//     if (!form.amount || !form.firstname || !form.email || !form.phone || !form.planName) {
//       alert('Please fill all required fields.');
//       return;
//     }

//     try {
//       setLoading(true);
//       const res = await axios.post(`${process.env.REACT_APP_API_URL}/select-plan`, {
//         phoneNumber: form.phone,
//         planId: form.planId,
//       });

//       await initiatePayUPayment(); // Proceed to PayU
//     } catch (error) {
//       const errMsg = error?.response?.data?.message || 'Something went wrong.';
//       if (errMsg.includes('already selected')) {
//         setPopup({
//           visible: true,
//           message: `You have already selected ${planName} plan. Please complete payment.`,
//           planName,
//         });
//       } else {
//         alert(errMsg);
//       }
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handlePayLater = async () => {
//     if (!form.amount || !form.firstname || !form.email || !form.phone || !form.planName) {
//       alert('Please fill all required fields.');
//       return;
//     }

//     try {
//       const postData = { ...form, payustatususer: 'pay later' };
//       await axios.post(`${process.env.REACT_APP_API_URL}/payu/payment-later`, postData);
//       alert('Your request to pay later is saved successfully.');
//       setForm((prev) => ({
//         ...prev,
//         txnid: 'txn_' + Date.now(),
//         email: `owner${Date.now()}@gmail.com`, // Regenerate email
//       }));
//     } catch (error) {
//       alert('Failed to save pay later. Please try again.');
//     }
//   };

//   const handleContinue = async () => {
//     setPopup({ visible: false, message: '', planName: '' });
//     await initiatePayUPayment();
//   };

//   const handleRemove = async () => {
//     try {
//       await axios.put(`${process.env.REACT_APP_API_URL}/plans/remove-phone/${form.phone}`);
//       alert('Phone number removed from selected plan.');
//       setPopup({ visible: false, message: '', planName: '' });
//     } catch (err) {
//       alert('Failed to remove phone number. Please try again.');
//     }
//   };

//   return (
//     <div style={containerStyle}>
//       <h2 style={titleStyle}>PayU Payment</h2>
//       <form>
//         <label style={labelStyle}>Plan</label>
//         <input type="text" value={form.planName} readOnly style={inputStyle} />

//         <label style={labelStyle}>Amount</label>
//         <input type="number" value={form.amount} readOnly style={inputStyle} />

//         <label style={labelStyle}>Phone Number</label>
//         <input type="tel" value={form.phone} readOnly style={inputStyle} />

//         <label style={labelStyle}>Full Name</label>
//         <input type="text" name="firstname" value={form.firstname} onChange={handleChange} style={inputStyle} />

//         <label style={labelStyle}>Email</label>
//         <input type="email" name="email" value={form.email} onChange={handleChange} style={inputStyle} />

//         <div style={buttonGroupStyle}>
//           <button type="button" style={payLaterStyle} onClick={handlePayLater} disabled={loading}>
//             Pay Later
//           </button>
//           <button type="submit" style={payNowStyle} onClick={handlePayNow} disabled={loading}>
//             {loading ? 'Processing...' : 'Pay Now'}
//           </button>
//         </div>
//       </form>

//       {popup.visible && (
//         <div
//           style={{
//             position: 'fixed',
//             top: 0, left: 0, right: 0, bottom: 0,
//             backgroundColor: 'rgba(0,0,0,0.5)',
//             display: 'flex',
//             justifyContent: 'center',
//             alignItems: 'center',
//             zIndex: 9999,
//           }}
//         >
//           <div
//             style={{
//               backgroundColor: '#fff',
//               padding: 20,
//               borderRadius: 10,
//               textAlign: 'center',
//               maxWidth: 300,
//               color: 'grey',
//             }}
//           >
//             <p>{popup.message}</p>
//             <div className="d-flex justify-content-between">
//               <button onClick={handleContinue} style={{ background: 'blue', color: 'white' }}>
//                 Continue to Pay
//               </button>
//               <button
//                 onClick={handleRemove}
//                 style={{
//                   background: 'white',
//                   color: 'blue',
//                   boxShadow: '0 4px 8px rgba(0, 123, 255, 0.3)',
//                 }}
//               >
//                 Remove
//               </button>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default PayUForm;
